/*
 * File:   newmain.c
 * Author: derek
 *
 * Created on March 22, 2016, 12:09 PM
 * 
 * You are free to do whatever you wish with this source code as long
 * as it is legal and you promise not to get your (or other's) fingers, toes,
 * miscellaneous body parts damaged by inserting them into a mechanical device
 * controlled by aforementioned source code. Failure to abide by this request,
 * well, then you just can't use it. But then it's too late anyway and...
 * I told you so.
 */

#define _XTAL_FREQ 8000000           // crystal freq defined as 8 MHz
// CONFIG1
#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTRC oscillator; port I/O function on both RA6/OSC2/CLKO pin and RA7/OSC1/CLKI pin)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // RA5/MCLR/VPP Pin Function Select bit (RA5/MCLR/VPP pin function is MCLR)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF         // Low-Voltage Programming Enable bit (RB3/PGM pin has PGM function, Low-Voltage Programming enabled)
#pragma config CPD = OFF        // Data EE Memory Code Protection bit (Code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off)
#pragma config CCPMX = RB0      // CCP1 Pin Selection bit (CCP1 function on RB0)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)
// CONFIG2
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor enabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal External Switchover mode disabled)

#include <xc.h>

// motor & timer defines
#define MOT_STPS_REV    200                 // steps per revolution of motor
#define LIN_DISTANCE    3                   // distance needed to travel with linear actuator
#define LIN_PITCH       0.2                 // travel per revolution of linear actuator (inches)
#define MOT_UNKNOWN     0                   // motor in unknown velocity state
#define MOT_ACCEL       1                   // motor in acceleration state
#define MOT_MAXV        2                   // motor in max velocity state
#define MOT_DECEL       3                   // motor in deceleration state
#define MOT_TOTALSTP    3000                // total steps to achieve distance
#define MOT_STPACLDCL   1000                 // portion of above which is acl or dcl ramp
#define MOT_TOT_MIN_ACLDCL  2000            // total acl dcl ramp (or plateau)
#define TIMER2_MAXV     0x01                // max velocity
#define TIMER2_MINV     0xff                // starting velocity
#define TIMER2_INC      0x01                // increment step size during acl or dcl
#define TIMER2_INIT     0x30                // initial value of timer1 high register

#define RUNMODE_TRAP    0x01                // run trapezoidal profile
#define RUNMODE_RECT    0x02                // run rectangular profile

// global variables
int runmode = RUNMODE_TRAP;                 // default to running in trapezoidal mode
volatile int current_steps = 0;             // current step tracker
volatile int motor_state = MOT_ACCEL;       // are we in acl, maxv, or dcl
volatile int direction = 0;

void main(void) {
    
    // initialize variables
    current_steps = 0;
    direction = 0;
    
    OSCCON = 0b01111000;        // 8 MHz internal osc
    
    // disable analog
    ANSEL = 0x00;
    ADCON0bits.ADON = 0;
      
    // setup port direction
    TRISA = 0x00;               // PORTA all output
    TRISB = 0x0f;               // PORTB input for switches
    PORTA = 0x00;               // Clear PORTA

    PIR1 = 0;                   // Clear interrupts
    PIE1 = 0;                   // Clear interrupt enable
    
    // Timer1 Registers: 
    T1CONbits.T1CKPS1 = 0;      // bits 5-4  Prescaler Rate Select bits
    T1CONbits.T1CKPS0 = 0;
    T1CONbits.T1OSCEN = 1;      // Timer1 Oscillator Enable Control: bit 1=on
    T1CONbits.TMR1CS  = 0;      // Clock Source Select bit: 0=Internal clock (FOSC/4) / 1 = External clock from pin T1CKI (on the rising edge)
    T1CONbits.TMR1ON  = 1;      // enable timer1
    T1CONbits.T1INSYNC  = 1;    // do not sync with external clock
    TMR1H = 0xe0;
    TMR1L = 0x00;
    PIR1bits.TMR1IF = 0;        // clear interrupt
    PIE1bits.TMR1IE = 1;        // Enable timer1 interrupt
    
    // Timer2 Registers:
    T2CONbits.TOUTPS3 = 1;      // setup Postscale
    T2CONbits.TOUTPS2 = 1;
    T2CONbits.TOUTPS1 = 1;
    T2CONbits.TOUTPS0 = 1;
    T2CONbits.T2CKPS1 = 0;      // setup Prescale
    T2CONbits.T2CKPS0 = 1;
    PR2 = TIMER2_INIT;          // 0x30 = max speed for LINENG 5718M-17D-01 motor
    PIR1bits.TMR2IF = 0;        // clear interrupt
    PIE1bits.TMR2IE = 1;        // Enable timer2 interrupt
    T2CONbits.TMR2ON = 1;       // Timer2 ON
    
    INTCONbits.PEIE = 1;
    INTCONbits.GIE = 1;         // Enable global interrupts
    
    
    while(1)
    {
        if (PORTBbits.RB0 == 0)
            runmode = RUNMODE_RECT;
        else if (PORTBbits.RB1 == 0)
            runmode = RUNMODE_TRAP;
    }
    return;
}


void interrupt isr (void)
{
    int temp;
    
    current_steps++;
    
    // timer1 interrupt
    // check portion of accl/dcel, adjust PR2 accordingly
    if(PIR1bits.TMR1IF)
    {
        T1CONbits.TMR1ON  = 0;

        // setup motor state based on steps
        if (current_steps <= MOT_STPACLDCL)
            motor_state = MOT_ACCEL;   
        else if ((current_steps > MOT_STPACLDCL) && (current_steps <= MOT_TOT_MIN_ACLDCL))
            motor_state = MOT_MAXV;
        else if (current_steps > MOT_TOT_MIN_ACLDCL)
            motor_state = MOT_DECEL;


        if (runmode == RUNMODE_TRAP)
        {
            temp = PR2;
            if (motor_state == MOT_ACCEL)
            {
                if (temp > TIMER2_MAXV)
                    PR2 = temp - TIMER2_INC;
            }
            else if(motor_state == MOT_DECEL )
            {
                if (temp <= TIMER2_MINV)
                    PR2 = temp + TIMER2_INC;
            }
        }
        
        // check/set direction
        if (current_steps >= MOT_TOTALSTP)
        {
            current_steps = 0;
            // toggle direction bit
            if (direction == 0)
            {
                PORTAbits.RA0 = 1;
                direction = 1;
            }
            else if (direction == 1)
            {
                PORTAbits.RA0 = 0;
                direction = 0;
            }
        }
        T1CONbits.TMR1ON  = 1;
        PIR1bits.TMR1IF = 0; 
    }
    
    
    // timer2 interrupt
    // toggle pulse
    if(PIR1bits.TMR2IF)
    {
        T2CONbits.TMR2ON  = 0;
        
        if (PORTAbits.RA1 == 1)
            PORTAbits.RA1 = 0;
        if (PORTAbits.RA1 == 0)
            PORTAbits.RA1 = 1;
        
        T2CONbits.TMR2ON  = 1;
        PIR1bits.TMR2IF = 0;
    }
}